#ifndef SEC_HPP
#define SEC_HPP
#include "cos.hpp"
namespace t_math
{
    double sec(double args)
    {
        return 1 / cos(args);
    };
};
#endif // SEC_HPP
